package dot.empire.ja_project;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

/**
 * Order list activity.
 * Created 26/09/2018
 *
 * @author Matthew Van der Bijl (xq9x3wv31)
 */
public class List extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
    }
}
