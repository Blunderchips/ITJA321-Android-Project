package dot.empire.ja_project;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

/**
 * Launch activity.
 *
 * @author Matthew Van der Bijl (xq9x2wv31)
 */
public class MainActivity extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
